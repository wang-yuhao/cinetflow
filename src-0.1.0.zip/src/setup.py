from setuptools import find_packages, setup

setup(
    name='src',
    packages=find_packages(),
    version='0.1.0',
    description='Conception and Implementation of a realtime asset database based on NetFlow data',
    author='yuhao',
    license='MIT',
)

class CompilationError(SyntaxError):
    pass
